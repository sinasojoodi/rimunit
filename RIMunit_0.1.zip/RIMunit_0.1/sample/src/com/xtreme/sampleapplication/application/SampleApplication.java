package com.xtreme.sampleapplication.application;

import net.rim.device.api.ui.*;
import net.rim.device.api.ui.container.MainScreen;
import rimunit.TestRunnerScreen;

public class SampleApplication extends UiApplication {
  public static void main(String[] args){
    UiApplication app = new SampleApplication();

    if(args != null && args.length >0
        && args[0].indexOf("runtests") != -1){
      XTestSuite suite = new XTestSuite();
      TestRunnerScreen testScreen = new TestRunnerScreen(suite);
      app.pushScreen(testScreen);
    }

    app.enterEventDispatcher();
  }

  public SampleApplication(){
        MainScreen screen = new MainScreen();
        screen.setTitle("Sample Application by Xtreme Labs");
        pushScreen(screen);
    // ...
  }
}



