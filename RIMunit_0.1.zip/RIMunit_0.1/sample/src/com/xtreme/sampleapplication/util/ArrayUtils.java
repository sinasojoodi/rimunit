package com.xtreme.sampleapplication.util;

public class ArrayUtils {
  public static boolean contains(int[] a, int i) {
    for (int j = 0; j < a.length; j++) {
      if (a[j] == i) {
        return true;
      }
    }
    return false;
  }
}
