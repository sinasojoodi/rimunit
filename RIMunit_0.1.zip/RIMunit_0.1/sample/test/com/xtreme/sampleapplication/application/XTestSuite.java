package com.xtreme.sampleapplication.application;

import rimunit.TestSuite;
import com.xtreme.sampleapplication.util.ArrayUtilsTest;

public class XTestSuite extends TestSuite {
  protected Class[] suite() {
    return new Class[]{
        ArrayUtilsTest.TestContainsFunction.class,

    };
  }
}
