/*
 * rimunit is a unit-testing framework for Jave development on BlackBerry.
 * Copyright 2009 Xtreme Labs Inc.
 *
 * This file is part of rimunit.
 *
 * rimunit is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * rimunit is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with rimunit; if not, see <http://www.gnu.org/licenses/>
 * or write to:
 * The Free Software Foundation, Inc.
 * 51 Franklin St, Fifth Floor
 * Boston, MA  02110-1301  USA
 */

package rimunit;

//import com.unify.app.util.Logger;

public abstract class TestSuite {

  public TestSuiteResult runTests() {
    return runTests(new NullTestSuiteListener());
  }

  public TestSuiteResult runTests(TestResultListener listener) {
    TestSuiteResult result = new TestSuiteResult();
    runTests(suite(), result, listener);
    return result;
  }

  protected abstract Class[] suite();


  private void runTests(Class[] tests, TestSuiteResult result, TestResultListener listener) {
    long startTime = System.currentTimeMillis();
    for (int i = 0; i < tests.length; i++) {
      TestCase test = createTest(tests[i]);
      System.out.println(new StringBuffer().append("\n--------------------\n").append(test.getClass().getName()).toString());
      runSafely(test, result);
    }
    result.setElapsedTime(System.currentTimeMillis() - startTime);
    listener.testsFinished(result);
  }

  private void runSafely(TestCase test, TestSuiteResult result) {
    try {
      test.setUp();
    } catch (Exception e) {
      logException(e, "Exception during setUp()");
      result.addTestException(test, e.toString());
      return;
    }

    try {
      test.run();
      result.addTestSuccess(test);
    } catch (AssertionFailedException afe) {
      System.out.println(new StringBuffer().append("Test failed: ").append(afe.getDetailMessage()).toString());
      result.addTestFailure(test, afe.getDetailMessage());
    } catch (Exception e) {
      logException(e, "Exception running test");
      result.addTestException(test, e.toString());
    }

    try {
      test.tearDown();
    } catch (Exception e) {
      logException(e, "Exception during tearDown()");
      result.addTestException(test, e.toString());
    }
  }

  private void logException(Exception e, String message) {
    System.out.println(new StringBuffer().append(message).append(": ").append(e.toString()).toString());
    System.out.println(e);
  }

  private TestCase createTest(Class testClass) {
    try {
      return (TestCase) testClass.newInstance();
    } catch (InstantiationException e) {
      System.out.println(e);
      throw new RuntimeException(new StringBuffer().append("cannot instantiate ").append(testClass).toString());
    } catch (IllegalAccessException e) {
      System.out.println(e);
      throw new RuntimeException(new StringBuffer().append("cannot instantiate ").append(testClass).toString());
    }
  }
}
