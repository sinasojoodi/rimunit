/*
 * rimunit is a unit-testing framework for Jave development on BlackBerry.
 * Copyright 2009 Xtreme Labs Inc.
 *
 * This file is part of rimunit.
 *
 * rimunit is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * rimunit is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with rimunit; if not, see <http://www.gnu.org/licenses/>
 * or write to:
 * The Free Software Foundation, Inc.
 * 51 Franklin St, Fifth Floor
 * Boston, MA  02110-1301  USA
 */

package rimunit;

import java.util.Vector;

public class TestSuiteResult {
  Vector testResults = new Vector();
  private int exceptionCount = 0;
  private int successCount = 0;
  private int failureCount = 0;
  private long elapsedTime;

  public void addTestException(TestCase test, String exceptionMessage) {
    testResults.addElement(new TestResult(test.getClass().getName(), exceptionMessage, EXCEPTION));
    exceptionCount++;
  }

  public void addTestFailure(TestCase test, String failureMessage) {
    testResults.addElement(new TestResult(test.getClass().getName(), failureMessage, FAILURE));
    failureCount++;
  }

  public void addTestSuccess(TestCase test) {
    testResults.addElement(new TestResult(test.getClass().getName(), "", SUCCESS));
    successCount++;
  }


  static final int SUCCESS = 0;
  static final int FAILURE = 1;
  static final int EXCEPTION = 2;

  public int getTotalCount() {
    return successCount + failureCount + exceptionCount;
  }

  public int getSuccessCount() {
    return successCount;
  }

  public int getFailureCount() {
    return failureCount;
  }

  public int getExceptionCount() {
    return exceptionCount;
  }

  public String getSummaryString() {
    return new StringBuffer()
        .append(getTotalCount())
        .append(" tests, took ")
        .append(elapsedTime)
        .append("ms.  Passed: ")
        .append(getSuccessCount())
        .append(", failed: ")
        .append(getFailureCount())
        .append(", errors: ")
        .append(getExceptionCount())
        .append(".")
        .toString();
  }

  public boolean isSuccessful() {
    return getTotalCount() == getSuccessCount();
  }

  public void setElapsedTime(long elapsedTime) {
    this.elapsedTime = elapsedTime;
  }

  public static class TestResult {
    String testName;
    String message;
    int resultType;

    public TestResult(String testName, String message, int resultType) {
      this.testName = testName;
      this.message = message;
      this.resultType = resultType;
    }

    public boolean isSuccess() {
      return resultType == SUCCESS;
    }

    public boolean isFailure() {
      return resultType == FAILURE;
    }

    public boolean isException() {
      return resultType == EXCEPTION;
    }

    public String getDisplayString() {
      StringBuffer sb = new StringBuffer().append(testName);
      if (isSuccess()) {
        sb.append(": OK");
      } else if (isFailure()) {
        sb.append(": FAILED (");
        sb.append(message);
        sb.append(")");
      } else if (isException()) {
        sb.append(": EXCEPTION (");
        sb.append(message);
        sb.append(")");
      }
      return sb.toString();
    }
  }


}
