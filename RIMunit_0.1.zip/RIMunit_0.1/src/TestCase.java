/*
 * rimunit is a unit-testing framework for the Jave Development on BlackBerry
 * Copyright 2009 Xtreme Labs Inc.
 *
 * This file is part of rimunit.
 *
 * rimunit is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * rimunit is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with rimunit; if not, If not, see <http://www.gnu.org/licenses/>
 * or write to:
 * The Free Software Foundation, Inc.
 * 51 Franklin St, Fifth Floor
 * Boston, MA  02110-1301  USA
 */

package rimunit;

import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.Manager;
import net.rim.device.api.ui.component.ListField;
import net.rim.device.api.ui.component.ListFieldCallback;
import net.rim.device.api.util.Arrays;

public abstract class TestCase {

  private boolean objectsEqual(Object o1, Object o2) {
    if (o1 == o2) {
      return true;
    } else if (o1 == null || o2 == null) {
      return false;
    } else if (o1.getClass().isArray() && o2.getClass().isArray()) {
      return Arrays.equals((Object[]) o1, ((Object[]) o2));
    } else {
      return o1.equals(o2);
    }
  }

  protected void assertEquals(Object expected, Object actual) throws AssertionFailedException {
    assertEquals("", expected, actual);
  }

  protected void assertEquals(String message, Object expected, Object actual) throws AssertionFailedException {
    if (!objectsEqual(expected, actual)) {
      throw new AssertionFailedException(message, expected, actual);
    }
  }

  protected void assertEquals(int expected, int actual) throws AssertionFailedException {
    assertEquals("", expected, actual);
  }

  protected void assertEquals(String message, int expected, int actual) throws AssertionFailedException {
    if (expected != actual) {
      throw new AssertionFailedException(message, new Integer(expected), new Integer(actual));
    }
  }

  protected void assertEquals(long expected, long actual) throws AssertionFailedException {
    assertEquals("", expected, actual);
  }

  protected void assertEquals(String message, long expected, long actual) throws AssertionFailedException {
    if (expected != actual) {
      throw new AssertionFailedException(message, new Long(expected), new Long(actual));
    }
  }

  protected void assertSame(Object expected, Object actual) throws AssertionFailedException {
    assertSame("", expected, actual);
  }

  protected void assertSame(String message, Object expected, Object actual) throws AssertionFailedException {
    if (expected != actual) {
      throw new AssertionFailedException(message, expected, actual);
    }
  }

  protected void assertNotSame(Object expected, Object actual) throws AssertionFailedException {
    assertNotSame("", expected, actual);
  }

  protected void assertNotSame(String message, Object expected, Object actual) throws AssertionFailedException {
    if (expected == actual) {
      throw new AssertionFailedException(message, expected, actual);
    }
  }


  protected void assertTrue(boolean expression) throws AssertionFailedException {
    assertTrue("", expression);
  }

  protected void assertTrue(String message, boolean expression) throws AssertionFailedException {
    if (!expression) {
      throw new AssertionFailedException(message, "true", "false");
    }
  }

  protected void assertFalse(boolean expression) throws AssertionFailedException {
    assertFalse("", expression);
  }

  protected void assertFalse(String message, boolean expression) throws AssertionFailedException {
    if (expression) {
      throw new AssertionFailedException(message, "false", "true");
    }
  }

  protected void assertNull(Object o) throws AssertionFailedException {
    assertNull("", o);
  }

  protected void assertNull(String message, Object o) throws AssertionFailedException {
    if (o != null) {
      throw new AssertionFailedException(message, "null", o);
    }
  }

  protected void assertNotNull(Object o) throws AssertionFailedException {
    assertNotNull("", o);
  }

  protected void assertNotNull(String message, Object o) throws AssertionFailedException {
    if (o == null) {
      throw new AssertionFailedException(message, "not null", "null");
    }
  }

  protected void fail(String message) throws AssertionFailedException {
    throw new AssertionFailedException(message);
  }

  protected void pass(String message) {
  }

  public void assertHasField(String message, Manager manager, Class fieldClass) throws AssertionFailedException {
    assertTrue(message, countFields(manager, fieldClass) > 0);
  }

  public void assertHasNumberOfFields(String message, Manager manager, int expectedFieldCount, Class fieldClass) throws AssertionFailedException {
    assertTrue(message, countFields(manager, fieldClass) == expectedFieldCount);
  }

  private int countFields(Manager manager, Class fieldClass) {
    int matchingFieldCount = 0;

    int fieldCount = manager.getFieldCount();

    for (int i = 0; i < fieldCount; i++) {
      Field field = manager.getField(i);
      if (field instanceof Manager) {
        matchingFieldCount += countFields((Manager) field, fieldClass);
      } else if (field.getClass() == fieldClass) {
        matchingFieldCount++;
      }
    }

    return matchingFieldCount;
  }

  public void assertHasMatchingField(String message, Manager manager, Predicate predicate) throws AssertionFailedException {
    if (!hasMatchingField(manager, predicate)) {
      fail(message);
    }
  }

  private boolean hasMatchingField(Manager manager, Predicate predicate) {
    int fieldCount = manager.getFieldCount();
    for (int i = 0; i < fieldCount; i++) {
      Field field = manager.getField(i);
      if (field instanceof Manager) {
        if (hasMatchingField((Manager) field, predicate)) {
          return true;
        }
      } else if (predicate.predicate(field)) {
        return true;
      }
    }
    return false;
  }

  public void assertListFieldContains(String expected, ListField listField) throws AssertionFailedException {
    if (!listFieldContains(expected, listField)) {
      fail(new StringBuffer().append("Expected to find \"").append(expected).append("\" in list field").toString());
    }
  }

  public void assertListFieldDoesNotContain(String expected, ListField listField) throws AssertionFailedException {
    if (listFieldContains(expected, listField)) {
      fail(new StringBuffer().append("Expected to not find \"").append(expected).append("\" in list field").toString());
    }
  }

  public void assertContains(String expectedContents, String container) throws AssertionFailedException {
    if (!contains(expectedContents, container)) {
      fail(new StringBuffer().append("Expected to find \"").append(expectedContents).append("\" in string \"").append(container).append("\"").toString());
    }
  }

  public void assertDoesNotContain(String expectedContents, String container) throws AssertionFailedException {
    if (contains(expectedContents, container)) {
      fail(new StringBuffer().append("Expected to not find \"").append(expectedContents).append("\" in string \"").append(container).append("\"").toString());
    }
  }

  private boolean contains(String expectedContents, String container) {
    return container.indexOf(expectedContents) != -1;
  }

  private boolean listFieldContains(String contents, ListField listField) {
    ListFieldCallback callback = listField.getCallback();
    int size = listField.getSize();
    for (int i = 0; i < size; i++) {
      if (((String) callback.get(listField, i)).indexOf(contents) > -1) {
        return true;
      }
    }
    return false;
  }

  abstract public void run() throws Exception;

  public void setUp() throws Exception {
  }

  public void tearDown() throws Exception {
  }
}
