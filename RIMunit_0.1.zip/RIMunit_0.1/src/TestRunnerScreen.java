/*
 * rimunit is a unit-testing framework for Jave Development on BlackBerry
 * Copyright 2009 Xtreme Labs Inc.
 *
 * This file is part of rimunit.
 *
 * rimunit is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * rimunit is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with rimunit; if not, see <http://www.gnu.org/licenses/>
 * or write to:
 * The Free Software Foundation, Inc.
 * 51 Franklin St, Fifth Floor
 * Boston, MA  02110-1301  USA
 */

package rimunit;

import net.rim.device.api.ui.*;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.SeparatorField;
import net.rim.device.api.ui.container.MainScreen;
import net.rim.device.api.ui.container.VerticalFieldManager;

public class TestRunnerScreen extends MainScreen implements TestResultListener {
  private TestSuite testSuite;
  private boolean passingTestsAreShown = false;
  private TestSuiteResult result;
  private VerticalFieldManager testResultFieldManager;
  private TestStartStopListener testStartStopListener;

  public TestRunnerScreen(TestSuite testSuite, TestStartStopListener listener) {
    this.testSuite = testSuite;
    this.testStartStopListener = listener;
    showHeader();
    runTests();
  }

  public TestRunnerScreen(TestSuite testSuite) {
    this(testSuite, null);
  }


  private void showHeader() {
    setFont(getSystemFont(Font.PLAIN, 10));
    VerticalFieldManager manager = new VerticalFieldManager();

    LabelField header = new LabelField(testSuite.getClass().getName());
    header.setFont(getSystemFont(Font.BOLD, 12));
    manager.add(header);
    add(manager);

    testResultFieldManager = new VerticalFieldManager();
    testResultFieldManager.add(new LabelField("Running tests..."));
    add(testResultFieldManager);
  }

  private void runTests() {
    if (testStartStopListener != null) {
      testStartStopListener.testStarted();
    }
    final TestResultListener meAsTheListener = this;
    Thread testThread = new Thread() {
      public void run() {
        testSuite.runTests(meAsTheListener);
      }
    };
    testThread.start();
  }


  private void showResults() {

    if (testResultFieldManager != null) {
      delete(testResultFieldManager);
    }

    testResultFieldManager = new VerticalFieldManager();
    testResultFieldManager.add(new ResultBar(result.isSuccessful() ? Color.LIGHTGREEN : Color.RED));

    testResultFieldManager.add(new LabelField(result.getSummaryString()));

    testResultFieldManager.add(new SeparatorField());
    testResultFieldManager.add(new SeparatorField());

    ButtonField toggleShowPassingTestsButton = new ButtonField();
    toggleShowPassingTestsButton.setLabel(passingTestsAreShown ? "Hide Passing Tests" : "Show Passing Tests");
    toggleShowPassingTestsButton.setChangeListener(new FieldChangeListener() {
      public void fieldChanged(Field field, int i) {
        passingTestsAreShown = !passingTestsAreShown;
        UiApplication.getUiApplication().invokeLater(new Runnable() {
          public void run() {
            showResults();
          }
        });
      }
    });
    testResultFieldManager.add(toggleShowPassingTestsButton);
    testResultFieldManager.add(new SeparatorField());

    for (int i = 0; i < result.testResults.size(); i++) {
      TestSuiteResult.TestResult testResult = (TestSuiteResult.TestResult) result.testResults.elementAt(i);

      if ((testResult.isSuccess() && passingTestsAreShown) || !testResult.isSuccess()) {
        LabelField field = new LabelField(testResult.getDisplayString(), LabelField.FOCUSABLE);
        if (!testResult.isSuccess()) {
          field.setFont(getSystemFont(Font.BOLD, 10));
        }
        testResultFieldManager.add(field);
        testResultFieldManager.add(new SeparatorField());

      }
    }
    add(testResultFieldManager);

  }

  private Font getSystemFont(int fontStyle, int fontSize) {
    try {
      FontFamily fontFamily = FontFamily.forName("SYSTEM");
      return fontFamily.getFont(fontStyle, fontSize);
    } catch (ClassNotFoundException e) {
      System.out.println(e);
      return null;
    }
  }

  public void testsFinished(TestSuiteResult result) {
    this.result = result;
    UiApplication.getUiApplication().invokeLater(new Runnable() {
      public void run() {
        showResults();
        if (testStartStopListener != null) {
          testStartStopListener.testsFinished();
        }
      }
    });
  }


  static class ResultBar extends Field {

    int color;

    ResultBar(int color) {
      super();
      this.color = color;
    }

    protected void layout(int width, int height) {
      setExtent(width, 25);
    }

    protected void paint(Graphics graphics) {
      graphics.setColor(color);
      graphics.fillRect(0, 3, getWidth(), getHeight() - 10);
    }

  }


}
