/*
 * rimunit is a unit-testing framework for Jave development on BlackBerry.
 * Copyright 2009 Xtreme Labs Inc.
 *
 * This file is part of rimunit.
 *
 * rimunit is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * rimunit is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with rimunit; if not, see <http://www.gnu.org/licenses/>
 * or write to:
 * The Free Software Foundation, Inc.
 * 51 Franklin St, Fifth Floor
 * Boston, MA  02110-1301  USA
 */

package rimunit;

public class RimUnitTest {

  public static Class[] suite() {
    return new Class[] {TestBooleanAssertions.class};
  }

  public static class TestBooleanAssertions extends TestCase {
    public void run() throws Exception {

      assertFalse("false is false", false);
      try {
        assertFalse("true is not false", true);
        fail("assertion should have failed");
      } catch (AssertionFailedException afe) {
        pass("expected");
      }

      assertTrue("true is true", true);
      try {
        assertTrue("false is not false", false);
        fail("assertion should have failed");
      } catch (AssertionFailedException afe) {
        pass("expected");
      }
    }

  }

  public static class TestNullAssertions extends TestCase {
    public void run() throws Exception {

      assertNotNull("foo");
      assertNotNull("foo is not null", "foo");
      try {
        assertNotNull(null);
        fail("assertion should have failed");
      } catch (AssertionFailedException afe) {
        pass("expected");
      }

      assertNull(null);
      assertNull("null is null", null);
      try {
        assertNull("foo");
        fail("assertion should have failed");
      } catch (AssertionFailedException afe) {
        pass("expected");
      }
    }
  }

  public static class TestEqualityAssertions extends TestCase {
    public void run() throws Exception {

      assertEquals("foo", "foo");
      assertEquals("foo equals foo", "foo", "foo");
      assertEquals(1, 1);
      assertEquals("1 equals 1", 1, 1);
      assertEquals(100L, 100L);
      assertEquals("100L equals 100L", 100L, 100L);
      Object foo = new Object();
      Object bar = foo;
      assertSame(foo, bar);
      assertSame("foo is same as bar", foo, foo);

      try {
        assertEquals("foo", "bar");
        fail("assertion should have failed");
      } catch (AssertionFailedException afe) {
        pass("expected");
      }

      try {
        assertEquals(1, 2);
        fail("assertion should have failed");
      } catch (AssertionFailedException afe) {
        pass("expected");
      }

      bar = new Object();
      try {
        assertSame(foo, bar);
        fail("assertion should have failed");
      } catch (AssertionFailedException afe) {
        pass("expected");
      }

      assertNotSame(foo, bar);
      assertNotSame("foo not same as bar", foo, bar);
      try {
        assertNotSame(foo, foo);
        fail("assertion should have failed");
      } catch (AssertionFailedException afe) {
        pass("expected");
      }



    }
  }

  static class DummyPassingTest  extends TestCase {
    public void run() throws Exception {
      assertTrue(true);
    }
  }

  static class DummyFailingTest  extends TestCase {
    public void run() throws Exception {
      assertTrue(false);
    }
  }

  static class DummyCrashingTest  extends TestCase {
    public void run() throws Exception {
      throw new Exception("boo");
    }
  }


  public static class TestFailingTestSuite extends TestCase {

    public void run() throws Exception {

      TestSuite suite = new TestSuite() {
        protected Class[] suite() {
          return new Class[] {
            DummyPassingTest.class,
            DummyFailingTest.class,
            DummyCrashingTest.class,
            DummyPassingTest.class,
            DummyPassingTest.class,
            DummyFailingTest.class
          };
        }
      };

      TestSuiteResult result = suite.runTests();
      assertEquals("total count", 6, result.getTotalCount());
      assertEquals("success count", 3, result.getSuccessCount());
      assertEquals("failure count", 2, result.getFailureCount());
      assertEquals("exception count", 1, result.getExceptionCount());
      assertFalse("successful suite", result.isSuccessful());           
    }
  }
  public static class TestSuccessfulTestSuite extends TestCase {

    public void run() throws Exception {

      TestSuite suite = new TestSuite() {
        protected Class[] suite() {
          return new Class[]{
                  DummyPassingTest.class,
          };
        }
      };

      TestSuiteResult result = suite.runTests();
      assertEquals("total count", 1, result.getTotalCount());
      assertEquals("success count", 1, result.getSuccessCount());
      assertTrue("suite is succesful", result.isSuccessful());

    }
  }

  public static class TestAssertionFailedException extends TestCase {

    public void run() throws Exception {
      AssertionFailedException exception = new AssertionFailedException("foo");
      assertEquals("foo", exception.getDetailMessage());

      exception = new AssertionFailedException("foo", "something", "another thing");
      assertEquals("foo expected 'something' but was 'another thing'", exception.getDetailMessage());

    }
  }
}
